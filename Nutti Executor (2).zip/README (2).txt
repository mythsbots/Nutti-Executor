-------README--------
If your anti-virus blocks it please make an exception. I do not distribute or give away
malware. It is how I made it with an API. Anyway, just click on the application and it.

I made this in like, 10 minutes. It is a level 5 executor. It doesnt run OwlHub. But it
runs quite good. Anyway, enjoy the Nutti Executor!
